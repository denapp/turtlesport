package fr.turtlesport.geo.garmin.tcx;

/**
 * @author Denis Apparicio
 * 
 */
public class ActivityCreator {
  public String name;

  public String productID;

  public String versionMajor;

  public String versionMinor;

  public String buildMajor;

  public String buildMinor;
}
