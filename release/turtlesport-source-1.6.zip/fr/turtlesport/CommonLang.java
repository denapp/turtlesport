package fr.turtlesport;

/**
 * Classe pour les langues.
 * 
 * @author Denis Apparicio
 * 
 */
public class CommonLang {

}
