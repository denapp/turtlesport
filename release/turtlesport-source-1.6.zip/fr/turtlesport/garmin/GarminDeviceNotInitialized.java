package fr.turtlesport.garmin;

/**
 * @author Denis Apparicio
 *
 */
public class GarminDeviceNotInitialized extends RuntimeException {

  /**
   * 
   */
  public GarminDeviceNotInitialized() {
    super();
  }
  
}
