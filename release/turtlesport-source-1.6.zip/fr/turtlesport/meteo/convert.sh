convert 32px-mostlycloudy.png -resize 18x18 18px-mostlycloudy.png
convert 32px-cloudy.png -resize 18x18 18px-cloudy.png
convert 32px-fog.png -resize 18x18 18px-fog.png
convert 32px-heavyrain.png -resize 18x18 18px-heavyrain.png
convert 32px-mostlycloudy.png -resize 18x18 18px-mostlycloudy.png
convert 32px-mostlysunny.png -resize 18x18 18px-mostlysunny.png
convert 32px-rain.png -resize 18x18 18px-rain.png
convert 32px-snow.png -resize 18x18 18px-snow.png
convert 32px-storm.png -resize 18x18 18px-storm.png
convert 32px-sunny.png -resize 18x18 18px-sunny.png
convert 32px-unknown.png -resize 18x18 18px-unknown.png

